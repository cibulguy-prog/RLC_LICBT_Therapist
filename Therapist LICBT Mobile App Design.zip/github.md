repo: cibulguy-prog/RLC_LICBT_Therapist
branch: main

## Last sync
date: 2026-08-01T20:14:10Z

### Updated in this project
- Repo contained only a README (no existing app code) — built the site fresh in this project as Design Components.
- Created 5 pages: Home, About (נעים להכיר), Services (תחומי טיפול), Blog, Contact — condensed from the reference site screenshots the user shared.
- Blog page holds 2 placeholder article cards awaiting the user's real articles.

## Screen map
| Screen | Source |
|---|---|
| Home.dc.html | reference screenshots (se44.com preview) — hero, about teaser, services, testimonials, blog teaser, contact CTA |
| About.dc.html | reference screenshots — "נעים להכיר" personal story |
| Services.dc.html | reference screenshots — treatment areas (חרדה, דיכאון, OCD, קבוצתי) |
| Blog.dc.html | reference screenshots — blog intro; article content pending from user |
| Contact.dc.html | reference screenshots — address, phone, email, hours |
